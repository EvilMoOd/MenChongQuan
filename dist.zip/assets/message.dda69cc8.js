import{b as e}from"./vendor.4c4820cf.js";const p=e({setup(t){return(n,r)=>null}});export{p as default};
